package com.example.financeapp.domain.enums;

public enum TransactionType {
    INCOME,
    EXPENSE
}
