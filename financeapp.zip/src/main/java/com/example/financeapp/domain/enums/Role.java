package com.example.financeapp.domain.enums;

public enum Role {
    ROLE_USER,
    ROLE_ADMIN
}
