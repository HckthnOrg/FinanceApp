create database financeapp_db;
